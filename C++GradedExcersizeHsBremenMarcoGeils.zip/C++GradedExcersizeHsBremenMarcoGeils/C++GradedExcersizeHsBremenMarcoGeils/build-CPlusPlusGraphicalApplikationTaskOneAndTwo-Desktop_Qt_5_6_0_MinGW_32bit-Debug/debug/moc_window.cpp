/****************************************************************************
** Meta object code from reading C++ file 'window.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../CPlusPlusGraphicalApplikationTaskOneAndTwo/window.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'window.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Window_t {
    QByteArrayData data[18];
    char stringdata0[247];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Window_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Window_t qt_meta_stringdata_Window = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Window"
QT_MOC_LITERAL(1, 7, 4), // "open"
QT_MOC_LITERAL(2, 12, 0), // ""
QT_MOC_LITERAL(3, 13, 6), // "zoomIn"
QT_MOC_LITERAL(4, 20, 7), // "zoomOut"
QT_MOC_LITERAL(5, 28, 10), // "normalSize"
QT_MOC_LITERAL(6, 39, 11), // "fitToWindow"
QT_MOC_LITERAL(7, 51, 15), // "basicIndicators"
QT_MOC_LITERAL(8, 67, 13), // "openHistogram"
QT_MOC_LITERAL(9, 81, 11), // "smoothImage"
QT_MOC_LITERAL(10, 93, 1), // "n"
QT_MOC_LITERAL(11, 95, 14), // "thresholdImage"
QT_MOC_LITERAL(12, 110, 6), // "nLevel"
QT_MOC_LITERAL(13, 117, 21), // "calculateSizeOfObject"
QT_MOC_LITERAL(14, 139, 27), // "calculateGradiantHorizontal"
QT_MOC_LITERAL(15, 167, 25), // "calculateGradiantVertical"
QT_MOC_LITERAL(16, 193, 26), // "calculateGradiantMagnitude"
QT_MOC_LITERAL(17, 220, 26) // "calculateGradiantDirection"

    },
    "Window\0open\0\0zoomIn\0zoomOut\0normalSize\0"
    "fitToWindow\0basicIndicators\0openHistogram\0"
    "smoothImage\0n\0thresholdImage\0nLevel\0"
    "calculateSizeOfObject\0calculateGradiantHorizontal\0"
    "calculateGradiantVertical\0"
    "calculateGradiantMagnitude\0"
    "calculateGradiantDirection"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Window[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   94,    2, 0x08 /* Private */,
       3,    0,   95,    2, 0x08 /* Private */,
       4,    0,   96,    2, 0x08 /* Private */,
       5,    0,   97,    2, 0x08 /* Private */,
       6,    0,   98,    2, 0x08 /* Private */,
       7,    0,   99,    2, 0x08 /* Private */,
       8,    0,  100,    2, 0x08 /* Private */,
       9,    0,  101,    2, 0x08 /* Private */,
       9,    1,  102,    2, 0x08 /* Private */,
      11,    0,  105,    2, 0x08 /* Private */,
      11,    1,  106,    2, 0x08 /* Private */,
      13,    0,  109,    2, 0x08 /* Private */,
      14,    0,  110,    2, 0x08 /* Private */,
      15,    0,  111,    2, 0x08 /* Private */,
      16,    0,  112,    2, 0x08 /* Private */,
      17,    0,  113,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Window::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Window *_t = static_cast<Window *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->open(); break;
        case 1: _t->zoomIn(); break;
        case 2: _t->zoomOut(); break;
        case 3: _t->normalSize(); break;
        case 4: _t->fitToWindow(); break;
        case 5: _t->basicIndicators(); break;
        case 6: _t->openHistogram(); break;
        case 7: _t->smoothImage(); break;
        case 8: _t->smoothImage((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->thresholdImage(); break;
        case 10: _t->thresholdImage((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->calculateSizeOfObject(); break;
        case 12: _t->calculateGradiantHorizontal(); break;
        case 13: _t->calculateGradiantVertical(); break;
        case 14: _t->calculateGradiantMagnitude(); break;
        case 15: _t->calculateGradiantDirection(); break;
        default: ;
        }
    }
}

const QMetaObject Window::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Window.data,
      qt_meta_data_Window,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Window::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Window::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Window.stringdata0))
        return static_cast<void*>(const_cast< Window*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Window::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
