#ifndef THRESHOLDER_H
#define THRESHOLDER_H
#include "QImage"

class Thresholder
{
public:
    Thresholder();

    void setImage(QImage* i);
    void thresholdImage(int n);
    QImage getNewImage();

private:
    QImage* binaryImage;
    QImage* image;
};

#endif // THRESHOLDER_H
