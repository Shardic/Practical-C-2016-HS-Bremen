#ifndef GRADIENTCALCULATOR_H
#define GRADIENTCALCULATOR_H
#include "QImage"

class GradientCalculator
{
public:
    GradientCalculator();

    void setImage(QImage* i);

    void calculateGradientImageX();
    void calculateGradientImageY();
    void calculateGradientImageMagnitude();
    void calculateGradientImageDirection();


    QImage getGradientImageX();
    QImage getGradientImageY();
    QImage getGradientImageMagnitude();
    QImage getGradientImageDirection();

private:
    //Oridinal image:
    QImage* image;

    QImage* gradientImageX;
    QImage* gradientImageY;
    QImage* gradientImageMagnitude;
    QImage* gradientImageDirection;
};

#endif // GRADIENTCALCULATOR_H
