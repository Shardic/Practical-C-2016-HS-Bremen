#ifndef MENUBUILDER_H
#define MENUBUILDER_H


class menuBuilder
{
public:
    menuBuilder();
};

#endif // MENUBUILDER_H