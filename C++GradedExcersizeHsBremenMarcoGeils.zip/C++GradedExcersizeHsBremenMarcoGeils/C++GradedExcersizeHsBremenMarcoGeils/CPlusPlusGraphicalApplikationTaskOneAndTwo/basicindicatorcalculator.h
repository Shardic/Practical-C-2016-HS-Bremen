#ifndef BASICINDICATORCALCULATOR_H
#define BASICINDICATORCALCULATOR_H
#include "QImage"

class BasicIndicatorCalculator
{
public:
    BasicIndicatorCalculator();
    ~BasicIndicatorCalculator();
    void setImage(QImage* i);
    void calculate();
    void showIndicators();

    void calculateStandartDeviation();

    int getMinimum();
    int getMaximum();
    int getAverage();
    int getStandartDeviation();

private:

    QImage* image;

    int minimum;
    int maximum;
    double average;
    double standartDeviation;

};

#endif // BASICINDICATORCALCULATOR_H
