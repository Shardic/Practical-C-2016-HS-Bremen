#include "gradientcalculator.h"
#include "math.h"

#define PI 3.14159265

GradientCalculator::GradientCalculator()
{

}

void GradientCalculator::setImage(QImage* i) {
     this->image = i;
}

void GradientCalculator::calculateGradientImageX(){
    gradientImageX = new QImage(image->size(),image->format());

    int width = image->width();
    int height = image->height();

    QColor requestedPixel;
    int IleftPixel = 0;
    int IrightPixel = 0;
    float ItoSet = 0;

    QColor* newPixelColor = new QColor(ItoSet,ItoSet,ItoSet,255);

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            if (i == 0) {
                requestedPixel = image->pixelColor(i + 1,j);
                IrightPixel = requestedPixel.red();
                requestedPixel = image->pixelColor(i,j);
                ItoSet = (requestedPixel.red() - IrightPixel) / 2;
            } else if (i == width -1) {
                requestedPixel = image->pixelColor(i - 1,j);
                IleftPixel = requestedPixel.red();
                requestedPixel = image->pixelColor(i,j);
                ItoSet = (requestedPixel.red()- IleftPixel) / 2;
            } else {
                requestedPixel = image->pixelColor(i+1,j);
                IrightPixel = requestedPixel.red();
                //IrightPixel = requestedPixel.red() * 0.2126 + requestedPixel.blue() * 0.0722 + requestedPixel.green()*0.7152;
                requestedPixel = image->pixelColor(i-1,j);
                IleftPixel = requestedPixel.red();
                //IleftPixel = requestedPixel.red() * 0.2126 + requestedPixel.blue() * 0.0722 + requestedPixel.green()*0.7152;
                ItoSet = (IrightPixel-IleftPixel) /2;
            }
            if (ItoSet < 0) {
                ItoSet *= -1;
            }
            ItoSet = ItoSet;
            newPixelColor->setRed(ItoSet);
            newPixelColor->setBlue(ItoSet);
            newPixelColor->setGreen(ItoSet);
            gradientImageX->setPixelColor(i,j,*newPixelColor);
        }
    }
}

void GradientCalculator::calculateGradientImageY(){
    gradientImageY = new QImage(image->size(),image->format());

    int width = image->width();
    int height = image->height();

    QColor requestedPixel;
    int IupperPixel = 0;
    int IlowerPixel = 0;
    float ItoSet = 0;

    QColor* newPixelColor = new QColor(ItoSet,ItoSet,ItoSet,255);

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            if (j == 0) {
                requestedPixel = image->pixelColor(i,j + 1);
                IlowerPixel = requestedPixel.red();
                requestedPixel = image->pixelColor(i,j);
                ItoSet = (requestedPixel.red() - IlowerPixel) / 2;
            } else if (j == height -1) {
                requestedPixel = image->pixelColor(i,j-1);
                IupperPixel = requestedPixel.red();
                requestedPixel = image->pixelColor(i,j);
                ItoSet = (requestedPixel.red()- IupperPixel) / 2;
            } else {
                requestedPixel = image->pixelColor(i,j+1);
                IlowerPixel = requestedPixel.red();
                requestedPixel = image->pixelColor(i,j-1);
                IupperPixel = requestedPixel.red();
                ItoSet = (IlowerPixel-IupperPixel) /2;
            }
            if (ItoSet < 0) {
                ItoSet *= -1;
            }
            ItoSet = ItoSet;
            newPixelColor->setRed(ItoSet);
            newPixelColor->setBlue(ItoSet);
            newPixelColor->setGreen(ItoSet);
            gradientImageY->setPixelColor(i,j,*newPixelColor);
        }
    }
}

void GradientCalculator::calculateGradientImageMagnitude(){
    gradientImageMagnitude = new QImage(image->size(),image->format());

    this->calculateGradientImageX();
    this->calculateGradientImageY();

    int width = image->width();
    int height = image->height();

    int GradientX = 0;
    int GradientY = 0;
    int sqrtGX = 0;
    int sqrtGY = 0;
    int newColorInt = 0;

    QColor requestedPixel;
    QColor* newPixelColor = new QColor(0,0,0,255);

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            requestedPixel = gradientImageX->pixelColor(i,j);
            GradientX = requestedPixel.red();
            requestedPixel = gradientImageY->pixelColor(i,j);
            GradientY = requestedPixel.red();

            sqrtGX = GradientX * GradientX;
            sqrtGY = GradientY * GradientY;

            newColorInt = sqrt(sqrtGX +sqrtGY);

            newPixelColor->setRed(newColorInt);
            newPixelColor->setBlue(newColorInt);
            newPixelColor->setGreen(newColorInt);

            gradientImageMagnitude->setPixelColor(i,j,*newPixelColor);
        }
    }
}

void GradientCalculator::calculateGradientImageDirection(){
    gradientImageDirection = new QImage(image->size(),image->format());

    this->calculateGradientImageX();
    this->calculateGradientImageY();

    int width = image->width();
    int height = image->height();

    int GradientX = 0;
    float GradientY = 0;
    float newColorInt = 0;

    QColor requestedPixel;
    QColor* newPixelColor = new QColor(0,0,0,255);

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            requestedPixel = gradientImageX->pixelColor(i,j);
            GradientX = requestedPixel.red();
            requestedPixel = gradientImageY->pixelColor(i,j);
            GradientY = requestedPixel.red();
            if (GradientY == 0) {
                GradientY = 0.001f;
            }

            int putInAtan(GradientX/GradientY);
            if (putInAtan > 255) {
                putInAtan = 255;
            }

            newColorInt = atan(putInAtan) * 180 / PI;

            newPixelColor->setRed(newColorInt);
            newPixelColor->setBlue(newColorInt);
            newPixelColor->setGreen(newColorInt);

            gradientImageDirection->setPixelColor(i,j,*newPixelColor);
        }
    }
}


QImage GradientCalculator::getGradientImageX() {
    return *gradientImageX;
}

QImage GradientCalculator::getGradientImageY(){
    return *gradientImageY;
}

QImage GradientCalculator::getGradientImageMagnitude(){
    return *gradientImageMagnitude;
}

QImage GradientCalculator::getGradientImageDirection(){
    return *gradientImageDirection;
}
