#ifndef IMAGESMOOTHER_H
#define IMAGESMOOTHER_H
#include "QImage"

class ImageSmoother
{
public:
    ImageSmoother();
    ~ImageSmoother();

    void setImage(QImage* i);
    void smootheImage(int n);
    QImage getNewImage();

private:
    QImage* smoothedImage;
    QImage* image;
};

#endif // IMAGESMOOTHER_H
