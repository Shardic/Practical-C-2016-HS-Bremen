#include "thresholder.h"

Thresholder::Thresholder()
{

}

void Thresholder::setImage(QImage *i) {
    this->image = i;
}

void Thresholder::thresholdImage(int n) {
    binaryImage = new QImage(image->size(),image->format());

    QColor* black = new QColor(0,0,0,255);
    QColor* white = new QColor(255,255,255,255);

    int width = image->width();
    int height = image->height();

    int actualColorInt = 0;
    QColor actualColor;

    for (int k = 0; k < width; k++) {
        for (int j = 0; j < height; j++) {
            actualColor = image->pixelColor(k,j);
            actualColorInt = actualColor.red();
            if(actualColorInt <= n) {
                binaryImage->setPixelColor(k,j,*black);
            } else if (actualColorInt > n) {
                binaryImage->setPixelColor(k,j,*white);
            }
        }
    }
}

QImage Thresholder::getNewImage() {
    return *binaryImage;
}
