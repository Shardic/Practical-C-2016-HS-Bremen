#include "basicindicatorcalculator.h"
#include "QRgb"
#include "QColor"
#include "iostream"
#include "math.h"
#include "QDialog"
#include "QAction"
#include "QListView"

BasicIndicatorCalculator::BasicIndicatorCalculator()
{   

}

BasicIndicatorCalculator::~BasicIndicatorCalculator(){

}

void BasicIndicatorCalculator::setImage(QImage* i) {
    this->image= i;
}

void BasicIndicatorCalculator::calculate(){
    int width = image->width();
    int height = image->height();

    minimum = 255;
    maximum = 0;
    int countOfPixels = width*height;
    int sumOfPixels = 0;

    int colorInt = 0;
    QColor rgb;

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            rgb = image->pixelColor(i,j);
            colorInt = rgb.red();
            sumOfPixels += colorInt;
            if (colorInt < minimum) {
                minimum = colorInt;
            }
            if (colorInt > maximum) {
                maximum = colorInt;
            }
        }
    }

    average = sumOfPixels / countOfPixels;

    double powVariance;
    double sumOfPow = 0;
    double variance;

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            rgb = image->pixelColor(i,j);
            colorInt = rgb.red();
            variance = colorInt - average;
            powVariance = pow(variance, 2);
            sumOfPow += powVariance;
        }
    }
    double x = sumOfPow / (sumOfPixels);
    standartDeviation = sqrt(x);
}

void BasicIndicatorCalculator::showIndicators(){
    std::cout << "opens indicators" << std::endl;
    std::cout << "minimum: " << minimum << std::endl;
    std::cout << "maximum: " << maximum << std::endl;
    std::cout << "average: " << average << std::endl;
    std::cout << "stdDeviation: " << standartDeviation << std::endl;
}

int BasicIndicatorCalculator::getMinimum() {
    return minimum;
}

int BasicIndicatorCalculator::getMaximum() {
    return maximum;
}

int BasicIndicatorCalculator::getAverage() {
    return average;
}

int BasicIndicatorCalculator::getStandartDeviation() {
    return standartDeviation;
}


