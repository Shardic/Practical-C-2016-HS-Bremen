#include "imagesmoother.h"
#include "QRgb"
#include "QColor"

ImageSmoother::ImageSmoother()
{
}

ImageSmoother::~ImageSmoother() {
}

void ImageSmoother::setImage(QImage *i) {
    this->image = i;
}

void ImageSmoother::smootheImage(int n) {
    if (n < 3) {
        //Return if N is under 3 because there would be no smoothing.
        //In an EE Level deployment it should throw a meaningful exception
        return;
    }
    smoothedImage = new QImage(image->size(),image->format());
    int checkIfZero = 0;
    int stepForNeighbeirhood = 0;
    int nMinusOne = n - 1;
    checkIfZero = n % 2;
    if (checkIfZero == 0) {
        // in case e.g. N = 3 ; n-1 = 2; 2/2 is 1 in each direction to get a 3x3 neighbeirhood
        stepForNeighbeirhood = nMinusOne / 2;
    } else {
        stepForNeighbeirhood = (nMinusOne - 1) / 2;
    }

    QColor* averagedColor = new QColor(0,0,0,255);

    int width = image->width();
    int height = image->height();
    int colorSum = 0;
    QColor actualColor;

    for (int k = 0; k < width; k++) {
        for (int j = 0; j < height; j++) {
            colorSum = 0;
            int numberOFNeighbours = 0;
            int minX = k - stepForNeighbeirhood;
            int minY = j - stepForNeighbeirhood;
            int maxX = k + stepForNeighbeirhood;
            int maxY = j + stepForNeighbeirhood;
            if (minX < 0) {
                minX = 0;
            }
            if (minY < 0) {
                minY = 0;
            }
            if (maxX > width -1) {
                maxX = width-1;
            }
            if (maxY > height - 1) {
                maxY = height - 1;
            }
            int actualX = minX;
            int actualY = minY;

            do{
                do{
                    numberOFNeighbours++;
                    actualColor = image->pixelColor(actualX,actualY);
                    colorSum += actualColor.red();
                    actualX++;
                }while(actualX <= maxX);
                actualX = minX;
                actualY++;
            }while(actualY <= maxY);

            int averageColorInt = colorSum / numberOFNeighbours;
            averagedColor->setRed(averageColorInt);
            averagedColor->setGreen(averageColorInt);
            averagedColor->setBlue(averageColorInt);

            smoothedImage->setPixelColor(k,j,*averagedColor);
        }
    }


}

QImage ImageSmoother::getNewImage() {
    return *smoothedImage;
}
