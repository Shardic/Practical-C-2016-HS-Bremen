#include "histogram.h"
#include "QImage"
#include "QRgb"
#include "QColor"
#include "QDialog"
#include "QIODevice"
#include "QTextStream"
#include "QStringBuilder"
#include "QStandardPaths"
#include "QtWidgets/QMainWindow"
#include "QtCharts/QChartView"
#include "QtCharts/QBarSeries"
#include "QtCharts/QBarSet"
#include "QtCharts/QLegend"
#include "QtCharts/QBarCategoryAxis"
#include "QtCharts/QBarSet"
#include "QtCharts/QBarSeries"
#include <iostream>

QT_CHARTS_USE_NAMESPACE

Histogram::Histogram() {
}


void Histogram::setImage(QImage* i) {
    this->image = i;
}

void Histogram::calculateHistogram(){
    int width = image->width();
    int height = image->height();
    int colorInt = 0;
    QColor historgb;

    for (int i = 0; i < 256; i++) {
        histogramArray[i] = 0;
    }
    for (int k = 0; k < width; k++) {
        for (int j = 0; j < height; j++) {
            historgb = image->pixelColor(k,j);
            colorInt = historgb.red();
            histogramArray[colorInt]++;
        }
    }
}

void Histogram::openHistogram(){
    QBarSet *set = new QBarSet("Histogram From 0 to 255",NULL);
    QBarSeries *series = new QBarSeries();
    for (int i = 0; i < 256; i++) {
        set->append(histogramArray[i]);
    }
    series->append(set);
    chart->addSeries(series);
    chart->setTitle("Histogram");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    chart->createDefaultAxes();
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);

    QChartView *chartView = new QChartView(chart);
    chartView->setEnabled(true);
    chartView->resize(1000,563);
    chartView->setVisible(true);
}

void Histogram::safeAsTextFile() {
    QString filename = "Histogram.txt";
    QFile file(filename);
    if (file.open(QIODevice::ReadWrite)) {
        QTextStream stream(&file);
        for (int i = 0; i < 255; i++) {
            stream << i;
            stream << "\t";
            stream << histogramArray[i] << endl;
        }
    }
}
